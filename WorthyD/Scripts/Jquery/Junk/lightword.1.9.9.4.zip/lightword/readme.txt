

Hey, thanks for downloading my theme.
Notice: This is my first (free) wordpress theme.


Localization feature added in 1.5
Please contact me, if you like to contribute your own language.


CHANGELOG | v1.9
| Wider option (960px) via theme settings
| IE6 footer bug fix
| Comments Off bug in Opera
| Overflow:hidden bug on justified text
| Two Column categories on non-widegetized sidebar in separate file
| Custom CSS in theme settings
| Dropdown menus with one level
| Fixed Safari/Chrome comments moderation bug

CHANGELOG | v1.9.2
| Fixed z-index issues with dropdown menu
| Disqus bug fixed

CHANGELOG | V1.9.6
| Fixed lightbox problem
| Post author highlight WP2.8 fixed
| Two sidebars on Wide layout (BETA)
| Small bug fixes

CHANGELOG | V1.9.8
| Finnish translation updated, thanks to Tomi R.
| LightWord internal version check removed
| Italian translation updated
| Two columns version revised
| New Post Thumbnail Feature
| One comment per page bug fixed (wordpress.org/support/topic/357045)

CHANGELOG | 1.9.9
| Cufon is back, special thanks goes to Voyagerfan5761 (technobabbl.es)
| Finnish language updated (Tomi R. | www.rantom.fi)
| Fixes an issue that can occur when a user has magic_quotes switched to on (Steven L. | isomehowhate.com)
| Post author settings revised

CHANGELOG | 1.9.9.1
| Added danish and chinese (tradional) language file

CHANGELOG | 1.9.9.2
| Added bulgarian language file (thanks to Marin D.)

CHANGELOG | 1.9.9.3
| WP-PAGENAVI PLUGIN should work now
| Added some new admin panel fields
| Fixed stripslashes bug on theme settings fields
| Spanish language improved + some functions.php contribution by GeekRMX (www.ngeeks.com)
| A new Cufon settings option: CSS3 Font-face (modern browsers) --  Voyagerfan5761 (technobabbl.es) ideea

CHANGELOG | 1.9.9.4
| Fixed: Comment reply link on pages
| Fixed: Older/previous comments link on page

Best regards,
Andrei Luca
http://www.lightword-theme.org